<?php

function oblicz($a,$b){
    return (($a+2)/sqrt($b**2+8*$a));
}

?>